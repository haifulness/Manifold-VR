//	CurvedSpacesIDs.h
//
//	GeometryGamesIconID.h declares the application icon id.
//	Any other needed resource id's may be declared here.
//
//	For use with the GoRC resource compiler, please save
//	this file with Windows-style end-of-line markers (\r\n).
//
//	© 2013 by Jeff Weeks
//	See TermsOfUse.txt

#include "../Shared/Geometry Games Core - Win/GeometryGamesIconID.h"
