//	GeometryGames-Win32-LoadEntryPoints.h
//
//	© 2013 by Jeff Weeks
//	See TermsOfUse.txt

#include <stdbool.h>	//	for bool, true and false

extern bool LoadOpenGLFunctions(void);
