//	GeometryGamesWindowMac.h
//
//	© 2016 by Jeff Weeks
//	See TermsOfUse.txt

#import <Cocoa/Cocoa.h>


@interface GeometryGamesWindowMac : NSWindow

- (BOOL)canBecomeKeyWindow;

@end
